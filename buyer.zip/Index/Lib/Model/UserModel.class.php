<?php
	class UserModel extends Model{
		public function __construct(){
			parent::__construct();
		}
		public function is_true($uid){
			$info=$this->uid($uid);
			if($info['is_true']){
				return true;
			}else{
				return false;
			}
		}

		public function uid($uid){
			$where['uid']=$uid;
			$where['del']=0;
			$info=$this->where($where)->select();
			return $info[0];

		}
		public function create_user($info){
		//添加用户
			if(!$this->name($info['name'])){
				$re['status']=false;
				$re['con']="用戶名重複";
				return $re;
			}
			if(!$this->email($info['email'])){
				$re['status']=false;
				$re['con']="Email重複";
				return $re;
			}
			// if(!$this->phone($info['phone'])){
			// 	$re['status']=false;
			// 	$re['con']="電話重複";
			// 	return $re;
			// }
			// $code=D('Phone')->code($info['phone']);
			// if($code!=$info['code']){
			// 	$re['status']=false;
			// 	$re['con']="電話驗證碼錯誤";
			// 	return $re;
			// }
			$add['name']=$info['name'];
			$add['true_name']=$info['true_name'];
			$add['email']=$info['email'];
			$add['sex']=$info['sex'];
			$add['idcode_number']=$info['idcode_number'];
			// $add['phone']=$info['phone'];
			$add['salt']=$this->salt(0);
			$add['password']=md5(md5($info['password']).$add['salt']);
			$add['time']=time();
			$add['code']=md5($add['salt'].$this->salt(0));//email验证码
			$uid=$this->add($add);
			$this->history($uid);
			return $uid;
		}
		public function verify_phone($uid,$phone,$code){
			$info=$this->uid($uid);
			$sql_code=D('Phone')->code($phone);
			if($sql_code==$code){
				$info['phone']=$phone;
				$info['is_phone']=1;
				$this->save($info);
				return true;
			}else{
				return false;
			}
		}
		public function verify_phone_code($uid,$phone){
			$ip=$_SERVER['REMOTE_ADDR'];
			$where['phone']=$phone;
			$where['is_phone']=1;
			$where['del']=0;#可以删去
			$info=$this->where($where)->select();
			if($info){
				$re['status']=false;
				$re['con']="該手機已經註冊!";
			}else{
				$re=D('Phone')->phone($phone,$ip);
				if($re['status']){
					$info['uid']=$uid;
					$info['phone']=$phone;
					$this->save($info);
					$re['con']="已經發送驗證碼到妳的手機";
				}
			}
			return $re;
		}
		public function verify_email($code){
			$where['code']=$code;
			$info=$this->where($where)->order("time DESC")->select();
			if($info){
				$re['status']=true;
				$re['con']=$info[0]['email'];

				$info['0']['code']="1";
				$this->save($info[0]);//跟新，如果code为1表示已经验证
			}else{
				$re['status']=false;
				$re['con']="Error";
			}
			return $re;
		}
		public function verify_idcard($uid){
			//验证身份证
			$info=$this->uid($uid);
			if($info){
				$info['is_idcard']=1;
				$this->save($info);//存储
				return true;
			}else{
				return false;
			}

		}
		public function verify_s($uid){
			//验证身份证
			$info=$this->uid($uid);
			if($info){
				$info['is_s']=1;
				$this->save($info);//存储
				return true;
			}else{
				return false;
			}

		}
		public function verify_bank($uid){
			//验证身份证
			$info=$this->uid($uid);
			if($info){
				$info['is_bank']=1;
				$this->save($info);//存储
				return true;
			}else{
				return false;
			}

		}
		public function name($name){
		//用于调用 或者验证是否重复
			$where['name']=$name;
			$where['del']=0;
			$info=$this->where($where)->select();
			return $info[0];

		}
		public function email($email){
		//用于调用 或者验证是否重复
			$where['email']=$email;
			$where['del']=0;
			$info=$this->where($where)->select();
			return $info[0];
		}
		public function phone($phone){
		//用于调用 或者验证是否重复
			$where['phone']=$phone;
			$where['del']=0;
			$info=$this->where($where)->select();
			return $info[0];
		}
		public function update($info){
			//有多少数据更新多少数据A中处理
			$this->save($info);

		}
		public function add_point($uid,$point){
			#购买成功 添加积分
			$where['uid']=$uid;
			$where['del']=0;
			$this->where($where)->setInc('point',$point);
		}
		public function password($uid,$password){
			$info=$this->uid($uid);
			$verify=md5(md5($password).$info['salt']);
			if($verify==$info['password']){
				return true;
			}else{
				return false;
			}
		}
		public function change_password($uid,$old,$new){
			$verify=$this->password($uid,$old);
			if($verify){
				$save['uid']=$uid;
				$save['salt']=$this->salt(0);
				$save['password']=md5(md5($new).$save['salt']);
				if($this->save($save)){
					$re['status']=true;
					$re['con']="修改成功";
				}else{
					$re['status']=false;
					$re['con']="未知錯誤";
				}
			}else{
				$re['status']=false;
				$re['con']="原密碼錯誤";
			}
		}
		public function salt($uid=0){
			if($uid){
				$info=$this->uid($uid);
				return $info['salt'];
			}else{
				return mt_rand(100000,99999);
			}
		}
		protected function history($uid){
			$us['time']=time();
			$us['ip']=$_SERVER['REMOTE_ADDR'];
			$info=$this->uid($uid);
			$json=json_decode($info['history']);
			$json[]=$us;
			$info['history']=json_encode($json);
			$this->save($info);
		}

	}