<?php
	class PostModel extends Model{
		public function create_post($info){
			$info['time']=time();
			return $this->add($info);
		}
		public function list($tag=0){
			if($tag){
				$where['tag']=$tag;
			}
			$where['del']=0;
			return $this->where($where)->select();
		}
		public function pid($pid){
			$where['pid']=$pid;
			$where['del']=0;
			$info=$this->where($where)->select();
			return $info[0];
		}
		public function edit_post($info){
			#pid存在
			$info['utime']=time();
			return $this->save($info);
		}
		public function del_post($pid){
			$info=$this->pid($pid);
			if($info){
				$info['utime']=time();
				$info['del']=time();
				return $this->save($info);
			}else{
				return false;
			}
		}
	}