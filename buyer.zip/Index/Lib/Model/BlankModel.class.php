<?php
	class BlankModel extends Model{
		
	}