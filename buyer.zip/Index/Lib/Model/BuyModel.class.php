<?php
	class BuyModel extends Model{
		#status 0 取消 1创建 2审核 3更新价格 4确认付款 5支付成功
		public function create_buy($info){
			#uid tid url info
			$info['status']=1;
			$info['ctime']=time();
			return $this->add($info);
		}
		public function uid($uid,$type=0){
			$where['uid']=$uid;
			$where['del']=0;
			if($type){
				$where['status']=$type;
			}
			return $this->where($where)->select();
		}
		public function list($time,$type=0){
			$where['time']=array("gt",$time);
			$where['del']=0;
			if($type){
				$where['status']=$type;
			}
			return $this->where($where)->select();
		}
		public function tid($tid){
			$where['tid']=$tid;
			$where['del']=0;
			$info=$this->where($where)->select();
			return $info[0];
		}
		public function uid_tid($uid,$tid){
			$where['uid']=$uid;
			$where['tid']=$tid;
			$where['del']=0;
			$info=$this->where($where)->select();
			return $info[0];

		}
		public function money_tid($tid,$money){
			$info=$this->tid($tid);
			if($info['status']==1){
				$info['money']=$money;
				$info['utime']=time();
				$info['status']=3;
			}
			return $this->save($info);
		}
		public function change_status($tid,$status){
			$info=$this->tid($tid);
			$info['status']=$status;
			$info['utime']=time();
			return $this->save($info);
		}
		public function del_tid($tid){
			$info=$this->tid($tid);
			$info['del']=time();
			return $this->save($info);
		}
	}