<?php
	class TemplateModel extends Model{
		public function add_template($info){


			$add['pay_name']=$info['pay_name'];
			$add['pay_image']=$info['pay_image'];
			$add['pay_info']=$info['pay_info'];
			$add['pay_url']=$info['pay_url'];

			$info['time']=time();
			return $this->add($info);
		}
		public function update_template($info){
			$save['tid']=$info['tid'];
			$save['pay_name']=$info['pay_name'];
			$save['pay_image']=$info['pay_image'];
			$save['pay_info']=$info['pay_info'];
			$save['pay_url']=$info['pay_url'];
			return $this->save($info);
		}
		public function tid($tid){//通过Tid获取模板
			$where['tid']=$tid;
			$where['del']=0;
			$info=$this->where($where)->select();
			return $info[0];
		}
		public function list(){
			$where['tid']=$tid;
			$where['del']=0;
			return $this->where($where)->select();
		}
	}