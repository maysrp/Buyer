<?php
	class LevelModel extends Model{
		public function change($info){
			//修改level
			foreach ($info as $key => $value) {
				$save['level']=(int)$value['level'];
				$save['point']=(int)$value['point'];
				$save['percent']=(int)$value['percent'];
				$save['id']=$save['level'];
				$this->change_one($save);
			}
		}
		protected function change_one($info){
			$this->save($info);
		}
	}