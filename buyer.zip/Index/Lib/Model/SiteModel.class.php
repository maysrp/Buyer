<?php
	class SiteModel extends Model{
		public function site(){//返回网站设置
			return $this->find(1);
		}
		public function change($info){//有啥改啥
			$this->save($info);
			$this->history($info,__METHOD__);
		}
		protected function history($info,$method){
			$data['time']=time();
			$data['info']=$info;
			$data['method']=$method;

			$info=$this->find(1);

			$json=json_decode($info['history']);
			$json[]=$data;
			$info['history']=json_encode($json);
			$this->save($info);
		}
	}