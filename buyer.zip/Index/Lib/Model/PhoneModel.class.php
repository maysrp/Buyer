<?php
	class PhoneModel extends Model{
		public $day;
		public function __construct(){
			parent::__construct();
			$this->day=date("Ymd");
		}
		public function phone($phone,$ip){
			if($this->jugg_ip($ip)){
				if($this->is_ip($ip)){
					$re['con']=$this->update_phone($phone,$ip);
				}else{
					$re['con']=$this->add_phone($phone,$ip);
				}
				$re['status']=true;
			}else{
				$re['status']=false;
				$re['con']="每日每個IP最多申請3個驗證碼";
			}
			return $re;

		}
		protected function is_phone($phone){
			$where['phone']=$phone;
			$where['del']=0;
			$info=$this->where($where)->order("time DESC")->select();
			return $info[0];
		}
		protected function jugg_ip($ip){
			$info=$this->is_ip($ip);
			if($info){
				$day=date("Ymd",$info['time']);
				if($day==$this->day){
					if($info['num']>=3){
						return false;
					}else{
						return true;
					}
				}else{
					return true;
				}
			}else{
				return true;//没有直接返回正确
			}
		}
		protected function is_ip($ip){
			//是否存在IP
			$where['ip']=$ip;
			$info=$this->where($where)->select();
			return $info[0];
		}
		protected function update_phone($phone,$ip){
			$info=$this->is_ip($ip);
			if(date('Ymd',$info['time'])==$this->day){
				$info['code']=$this->code(0);
				$info['num']=$info['num']+1;
				$this->save($info);
				return $info['code'];
			}else{
				$info['code']=$this->code(0);
				$this->save($info);
				return $info['code'];
			}
		}
		protected function add_phone($phone,$ip){
			$add['phone']=$phone;
			$add['time']=time();
			$add['num']=1;
			$add['code']=$this->code(0);
			$add['ip']=$ip;
			$this->add($add);
			return $add['code'];
		}
		public function code($phone=0){
			if($phone){
				$info=$this->is_phone($phone);
				if($info){
					return $info['code'];
				}else{
					return false;
				}
			}else{
				$code=mt_rand(100000,999999);
				return $code;
			}
		}
	}